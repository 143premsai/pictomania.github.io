<?php
$msg= "";
session_start();

include_once 'dbconnect.php';

if(isset($_SESSION['user'])!="")
{
    $res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);


    $row=mysql_fetch_array($res);


        header("Location: home.php");

}


if(isset($_POST['btn-forgot1'])) {

    $email = mysql_real_escape_string($_POST['form-email']);
    $upass = md5(mysql_real_escape_string($_POST['form-password']));
    $upass1 = md5(mysql_real_escape_string($_POST['form-confirmpassword']));

    $res = mysql_query("SELECT * FROM users WHERE email='$email'");

    $row = mysql_fetch_array($res);

    if ($email == $row['email']) {
        if ($upass == $upass1) {
            mysql_query("UPDATE users SET password='$upass' WHERE email='$email'")
            ?>
            <script>
                window.location.href = "index.php";
            </script>
            <?php
        } else {
            $msg = "Mis match of passwords";
        }
    }
    else {
        ?>
        <script>
            location.href = "index.php";
        </script>
        <?php
    }

}



?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pictomania|Forgot </title>

    <!-- CSS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
    <link rel="stylesheet" href="assets/css/form.css">
    <link rel="stylesheet" href="assets/style.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">



</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>
<div class="navbar-wrapper">
    <div class="container">

        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation" id="top-nav">
            <div class="container">
                <div class="navbar-header">
                    <!-- Logo Starts -->
                    <a class="navbar-brand" href="#home"><img src="assets/images/logo.png" alt="logo"></a>
                    <!-- #Logo Ends -->


                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                </div>


                <!-- Nav Starts -->
                <div class="navbar-collapse  collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="login.php">Login</a></li>

                    </ul>
                </div>
                <!-- #Nav Ends -->

            </div>
        </div>

    </div>
</div>

<!-- Top content -->
<div class="top-content">

    <div class="inner-bg">
        <div class="container">

            <div class="row">
                <div class="col-sm-9 col-sm-offset-2 form-box">
                    <div class="col-sm-8">
                        <div class="form-top">
                            <div class="form-top-left">
                                <h3>Reset u r password</h3>
                                <p>Enter your username and email to Reset:</p>
                                        <span style="color:white; font-size: small">
                                            <?php echo $msg; ?>
                                        </span>

                            </div>
                            <div class="form-top-right">
                                <i class="fa fa-mail-forward"></i>
                            </div>
                        </div>
                        <div class="form-bottom">
                            <form role="form" name="forgot" method="post" class="forgot-form">
                                <div class="form-group">
                                    <label class="sr-only" for="form-email">Email</label>
                                    <input type="email" name="form-email" required placeholder="Email..." class="form-email form-control" id="form-email">
                                    <br>
                                    <label class="sr-only" for="form-password">Password</label>
                                    <input type="password" name="form-password" required placeholder="Password..." class="form-password form-control" id="form-password">
                                    <br>
                                    <label class="sr-only" for="form-confirmpassword">Password</label>
                                    <input type="password" name="form-confirmpassword" required placeholder="Confirm Password..." class="form-confirmpassword form-control" id="form-confirmpassword">
                                </div>
                                <button type="submit" name="btn-forgot1" class="btn">Continue</button>
                                <br>
                                <br>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>

</div>
<div class="footer text-center spacer">
    <p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-instagram fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-flickr fa-2x"></i></a> </p>
    Copyright 2015 Pictomania. All rights reserved.
</div>
<!-- # Footer Ends -->

<!-- Javascript -->
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.backstretch.min.js"></script>
<script src="assets/js/scripts.js"></script>

<!--[if lt IE 10]>
<script src="assets/js/placeholder.js"></script>
<![endif]-->

</body>

</html>