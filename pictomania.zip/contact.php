<?php
session_start();
$msg='';
include_once 'dbconnect.php';

if(!isset($_SESSION['user']))
{
    header("Location: index.php");
}
$res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);

if(isset($_POST['btn-support'])) {
    $uname = mysql_real_escape_string($_POST['username']);
    $email = mysql_real_escape_string($_POST['useremail']);
    $company = mysql_real_escape_string($_POST['usercompany']);

    $phone = mysql_real_escape_string($_POST['userphone']);
    $message = mysql_real_escape_string($_POST["usermessage"]);
    mysql_query("INSERT INTO support(name,email,company,phone,message) VALUES('$uname','$email','$company','$phone','$message')");

}

?>




<!DOCTYPE html>


<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pictomania|<?php echo $userRow['username']; ?></title>

    <!-- CSS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
    <link rel="stylesheet" href="assets/css/form.css">
    <link rel="stylesheet" href="assets/style.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">



</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>
<div class="navbar-wrapper">
    <div class="container">

        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation" id="top-nav">
            <div class="container">
                <div class="navbar-header">
                    <!-- Logo Starts -->
                    <a class="navbar-brand" href="#home"><img src="assets/images/logo.png" alt="logo"></a>
                    <!-- #Logo Ends -->


                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                </div>


                <!-- Nav Starts -->
                <div class="navbar-collapse  collapse">
                    <ul class="nav navbar-nav navbar-right text-center" color="blue" >
                        <li ><a href="home.php">Home</a></li>
                        <li ><a href="models.php">Models</a></li>
                        <li><a href="gallery.php">Gallery</a></li>
                        <li ><a href="contact.php">Contact</a></li>

                        <li><a href="logout.php?logout">hi' <?php echo $userRow['username']; ?> &nbsp; Sign Out</a></li>
                    </ul>
                </div>
                <!-- #Nav Ends -->

            </div>
        </div>

    </div>
</div>

<!-- Top content -->
<div class="top-content">

    <div class="inner-bg">
        <div class="container">

            <div class="row">
                <div class="col-sm-9 col-sm-offset-3 form-box">
                    <div class="col-sm-8">
                        <div class="form-top">
                            <div class="form-top-left">
                                <h3>Contact us</h3>
                                <p></p>



                            </div>
                            <div class="form-top-right">
                                <i class="fa fa-camera"></i>
                            </div>
                        </div>
                        <div class="form-bottom">
                            <form role="form"  method="post" class="signup-form">
                                <div class="form-group">
                                    <label class="sr-only" for="username">Name</label>
                                    <input type="text" name="username" required placeholder="Name..." class="form-username form-control" id="form-username">
                                    <br>
                                    <label class="sr-only" for="email">Email</label>
                                    <input type="email" name="useremail" required placeholder="Email..." class="form-email form-control" id="form-email">
                                    <br>
                                    <label class="sr-only" for="company">Password</label>
                                    <input type="text" name="usercompany" required placeholder="Company..." class="form-password form-control" id="form-password">

                                    <br>
                                    <label class="sr-only" for="form-phone">Phone</label>
                                    <input type="tel" required name="userphone" placeholder="Phone..." class="form-phone form-control" id="form-phone">
                                    <br>
                                    <label class="sr-only" for="usermessage">Confirm Password</label>
                                    <textarea rows="5" cols="50" placeholder="Message..." name="usermessage"></textarea>
                                    <br>
                                    <br>
                                </div>
                                <button class="btn btn-primary" name="btn-support"><i class="fa fa-paper-plane"></i> Send</button>
                            </form>
                        </div>



                                <?php
                                echo $msg.'<br/>';
                                ?>
                            </div>


                        </div>
                    </div>


                </div>
            </div>


        </div>
    </div>
</div>


<div class="footer text-center spacer">
    <p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-instagram fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-flickr fa-2x"></i></a> </p>
    Copyright 2015 Pictomania. All rights reserved.
</div>
<!-- # Footer Ends -->


<!-- Javascript -->
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.backstretch.min.js"></script>
<script src="assets/js/scripts.js"></script>

<!--[if lt IE 10]>
<script src="assets/js/placeholder.js"></script>
<![endif]-->

</body>

</html>



