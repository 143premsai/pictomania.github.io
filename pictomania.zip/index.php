<?php

session_start();

include_once 'dbconnect.php';

if(isset($_SESSION['user'])!="")
{
    $res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);


    $row=mysql_fetch_array($res);


        header("Location: home.php");

}

if(isset($_POST['btn-support'])) {
    $uname = mysql_real_escape_string($_POST['username']);
    $email = mysql_real_escape_string($_POST['useremail']);
    $company = mysql_real_escape_string($_POST['usercompany']);

    $phone = mysql_real_escape_string($_POST['userphone']);
    $message = mysql_real_escape_string($_POST["usermessage"]);
    mysql_query("INSERT INTO support(name,email,company,phone,message) VALUES('$uname','$email','$company','$phone','$message')");

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />

    <title>Pictomania</title>

    <!-- Google fonts -->
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

    <!-- font awesome -->
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />

    <!-- animate.css -->
    <link rel="stylesheet" href="assets/animate/animate.css" />
    <link rel="stylesheet" href="assets/animate/set.css" />

    <!-- gallery -->
    <link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">

    <!-- favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">


    <link rel="stylesheet" href="assets/style.css">

</head>

<body style="background:url("assets/images/bg.jpg")";>

<div class="topbar animated fadeInLeftBig"></div>
<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="#home"><img src="assets/images/logo.png" alt="logo"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right text-center" color="blue" >
                 <li ><a href="#home">Home</a></li>
                 <li ><a href="#about">About</a></li>
                  <li ><a href="#services">Services</a></li>
               
                 <li ><a href="models.php">Models</a></li>
                  <li><a href="gallery.php">Gallery</a></li>
                 <li ><a href="#contact">Contact</a></li>
                  <li><a href="login.php">Login</a></li>
                  <li><a href="signup.php">Signup</a></li>
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->




<div id="home">
<!-- Photo Slider Starts -->
<div id="myCarousel" class="carousel slide banner-slider animated bounceInDown" data-ride="carousel">     
      <div class="carousel-inner">
        <!-- Item 1 -->
        <div class="item active">
          <img src="assets/images/back/1.jpg" alt="banner">
        </div>
        <!-- #Item 1 -->



<?php
// integer starts at 0 before counting
$j = 0;
$dir = 'assets/images/back';
if ($handle = opendir($dir)) {
    while (($file = readdir($handle)) !== false){
        if (!in_array($file, array('.', '..')) && !is_dir($dir.$file))
            $j++;
    }
}

for($i=2;$i<$j+1;$i++){
?>
        <!-- Item 1 -->

        <div class="item">
            <?php echo '<img src="assets/images/back/'.$i.'.jpg" alt="banner"/>' ; ?>

        </div>
          <?php } ?>
        <!-- #Item 1 -->

      </div>

      <a class="left carousel-control" href="#myCarousel" data-slide="prev"><i class="glyphicon glyphicon-arrow-left"></i></a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next"><i class="glyphicon glyphicon-arrow-right"></i></a>
    </div>
<!-- #Slider Ends -->
</div>









<!-- ABOUT Cirlce Starts -->
<div id="about"  class="container spacer about">
<h2 class="text-center wowload fadeInUp">Creative photographers</h2>  
  <div class="row">
  <div class="col-sm-6 wowload fadeInLeft">
    <h4><i class="fa fa-camera-retro"></i> Introduction </h4>
    <p>Pictomania is a startup from the students , we deal commercial photography elements which includes fashion,weddings,events.</p>
    

  </div>
  <div class="col-sm-6 wowload fadeInRight">
  <h4><i class="fa fa-coffee"></i> Passion</h4>
  <p>Photography for me is a passion,A day without photography is the day the world without beauty.</p>    
  </div>
  <div id="services"></div>
    </div>

 
      
  <div class="services">
  <h3 class="text-center wowload fadeInUp" >Services</h3>
	<ul class="row text-center list-inline  wowload bounceInUp">
   		<li>
            <span><i class="fa fa-camera-retro"></i><b>Photography</b></span>
        </li>
        <li>
            <span><i class="fa fa-cube"></i><b>Studio</b></span>
        </li>
        <li>
            <span><i class="fa fa-graduation-cap"></i><b>Trainings</b></span>
        </li>
        <li>
            <span><i class="fa fa-umbrella"></i><b>Travel</b></span>
        </li>        
        <li>
            <span><i class="fa fa-heart"></i><b>Wedding</b></span>
        </li>
  	</ul>
  </div>
</div>
    

<!-- #Cirlce Ends -->




<!-- clients and team -->
 <div class="container spacer ">
	<h2 class="text-center  wowload fadeInUp">Some of our happy clients</h2>
  <div class="clearfix">
    <div class="col-sm-6">
        
        <div id="carousel-testimonials" class="carousel slide testimonails  wowload fadeInRight" data-ride="carousel">
    <div class="carousel-inner">  
      <div class="item active animated bounceInRight row">
      <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="assets/images/team/1.jpg" width="100" class="img-circle img-responsive"></div>
      <div  class="col-xs-10">
      <p> I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. </p>      
      <span>Angel Smith - <b>eshop Canada</b></span>
      </div>
      </div>

      <div class="item  animated bounceInRight row">
      <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="assets/images/team/2.jpg" width="100" class="img-circle img-responsive"></div>
      <div  class="col-xs-10">
      <p>No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.</p>
      <span>John Partic - <b>Crazy Pixel</b></span>
      </div>
      </div>
      <div class="item  animated bounceInRight row">
      <div class="animated slideInLeft  col-xs-2"><img alt="portfolio" src="assets/images/team/3.jpg" width="100" class="img-circle img-responsive"></div>
      <div  class="col-xs-10">
      <p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue.</p>
      <span>Harris David - <b>Jet London</b></span>
      </div>
      </div>
  </div>

   <!-- Indicators -->
   	<ol class="carousel-indicators">
    <li data-target="#carousel-testimonials" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-testimonials" data-slide-to="1"></li>
    <li data-target="#carousel-testimonials" data-slide-to="2"></li>
  	</ol>
  	<!-- Indicators -->
  </div>
        
    </div>
      
    <div class="col-sm-6">


    <div id="carousel-testimonials" class="carousel slide testimonails  wowload fadeInRight" data-ride="carousel">
    <div class="carousel-inner">
        <div class="item active animated bounceInRight row">
            <div class="animated slideInLeft  col-xs-2"><img alt="portfolio" src="assets/images/team/4.jpg" width="100" class="img-circle img-responsive"></div>
            <div  class="col-xs-10">
                <p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue.</p>
                <span>Harris David - <b>Jet London</b></span>
            </div>

      </div>
        <div class="item  animated bounceInRight row">
            <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="assets/images/team/5.jpg" width="100" class="img-circle img-responsive"></div>
            <div  class="col-xs-10">
                <p>No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.</p>
                <span>John Partic - <b>Crazy Pixel</b></span>
            </div>
        </div>

        <div class="item animated bounceInRight row">
            <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="assets/images/team/6.jpg" width="100" class="img-circle img-responsive"></div>
            <div  class="col-xs-10">
                <p> I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. </p>
                <span>Angel Smith - <b>eshop Canada</b></span>
            </div>
        </div>

  </div>

   <!-- Indicators -->
   	<ol class="carousel-indicators">
    <li data-target="#carousel-testimonials" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-testimonials" data-slide-to="1"></li>
    <li data-target="#carousel-testimonials" data-slide-to="2"></li>
  	</ol>
  	<!-- Indicators -->
  </div>



    </div>
  </div>
     


<!-- team -->
<h3 class="text-center  wowload fadeInUp">Our team</h3>

<div class="row grid team  wowload fadeInUpBig">	
	<div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="assets/images/team/10.jpg" alt="img01" class="img-responsive" />
        <figcaption>
            <p><b>Barbara Husto</b><br>Senior Designer</p>
        </figcaption>
    </figure>
    </div>

    <div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="assets/images/team/11.jpg" alt="img01"/>
        <figcaption>            
            <p><b>Barbara Husto</b><br>Senior Designer</p>
        </figcaption>
    </figure>
    </div>

    <div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="assets/images/team/12.jpg" alt="img01"/>
        <figcaption>
            <p><b>Barbara Husto</b><br>Senior Designer</p>
        </figcaption>
    </figure>
    </div>

    <div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="assets/images/team/13.jpg" alt="img01"/>
        <figcaption>
            <p><b>Barbara Husto</b><br>Senior Designer</p>
        </figcaption>
    </figure>
    </div>

 
</div>
<!-- team -->

</div>


 
 
    







<!-- Quote Starts -->
<div class="highlight-info">
<div class="overlay spacer">
<div class="container">
<div class="row text-center  wowload fadeInDownBig">
	<div class="col-sm-12 col-xs-12">
	<i class="fa fa-quote-left fa-5x"></i><h4>“When words become unclear, I shall focus with photographs. When images become inadequate, I shall be content with silence.” 
― Ansel Adams</h4>
	
	</div>
</div>
</div>
</div>
</div>
<!-- Quote Ends -->








<div id="contact" class="spacer">
<!--Contact Starts-->
<div class="container contactform center">
<h2 class="text-center  wowload fadeInUp">Get in touch with us</h2>
  <div class="row wowload fadeInLeftBig">      
      <div class="col-sm-6 col-sm-offset-3 col-xs-12">
          <form action="" method="post">
        <input type="text" placeholder="Name" name="username"/>
        <input type="email" placeholder="Email" name="useremail"/>
        <input type="text" placeholder="Company" name="usercompany">
        <input type="tel" placeholder="Phone number" name="userphone"/>
        <textarea rows="5" placeholder="Message" name="usermessage"></textarea>
        <button class="btn btn-primary" name="btn-support"><i class="fa fa-paper-plane"></i> Send</button>
          </form>
      </div>
  </div>



</div>
</div>
<!--Contact Ends-->



<!-- Footer Starts -->
<div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-instagram fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-flickr fa-2x"></i></a> </p>
Copyright 2015 Pictomania. All rights reserved.
</div>
<!-- # Footer Ends -->
<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>





<!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
    <!-- The container for the modal slides -->
    <div class="slides"></div>
    <!-- Controls for the borderless lightbox -->
    <h3 class="title">Title</h3>
    <a class="prev">‹</a>
    <a class="next">›</a>
    <a class="close">×</a>
    <!-- The modal dialog, which will be used to wrap the lightbox content -->    
</div>



<!-- jquery -->
<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="assets/script.js"></script>

</body>
</html>