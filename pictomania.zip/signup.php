<?php
session_start();
$msg="";
if(isset($_SESSION['user'])!="")
{
    header("Location: home.php");
}
include_once 'dbconnect.php';

if(isset($_POST['btn-signup'])) {
    $uname = mysql_real_escape_string($_POST['form-username']);
    $email = mysql_real_escape_string($_POST['form-email']);
    $upass = md5(mysql_real_escape_string($_POST['form-password']));
    $upass1 = md5(mysql_real_escape_string($_POST['form-confirmpassword']));
    $phone = mysql_real_escape_string($_POST['form-phone']);
    $gender = mysql_real_escape_string($_POST["form-gender"]);

    $res=mysql_query("SELECT email FROM users WHERE email='$email'");
    $res1=mysql_query("SELECT username FROM users WHERE username='$uname'");

    if(mysql_num_rows($res1)!=0) {
        $msg="User name already exists";
    }
    else{
        if(mysql_num_rows($res)!=0 ){

            $msg = "email already exists";
        }
        else{
                if ($upass == $upass1) {
                    if (mysql_query("INSERT INTO users(username,email,password,phone,gender) VALUES('$uname','$email','$upass','$phone','$gender')")) {
                        ?>
                        <script>
                            location.href = "index.php";
                        </script>
                        <?php
                    }
                    else {
                        $msg="error while registering you , please try later";
                    }
                }
                else {
                    $msg = "Passwords are not equal";
                }
        }
    }

}
?>

<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Pictomania|signup </title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/form.css">
		<link rel="stylesheet" href="assets/style.css">
          <!-- favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">
	<style>

</style>	
	
    </head>

    <body >
    <div class="topbar animated fadeInLeftBig"></div>
        <div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="#home"><img src="assets/images/logo.png" alt="logo"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
                 <li><a href="index.php">Home</a></li>
                  <li><a href="login.php">Login</a></li>
             
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    
                    <div class="row">
                        <div class="col-sm-9 col-sm-offset-2 form-box">
                        	<div class="col-sm-8">
								<div class="form-top">
									<div class="form-top-left">
										<h3>Signup for our site</h3>
                                        <span style="color:white; font-size: small">
                                            <?php echo $msg; ?>
                                        </span>
									</div>
									<div class="form-top-right">
										<i class="fa fa-lock"></i>
									</div>
								</div>
								<div class="form-bottom">
									<form role="form"  method="post" class="signup-form">
										<div class="form-group">
											<label class="sr-only" for="form-username">Username</label>
											<input type="text" name="form-username" required placeholder="Username..." class="form-username form-control" id="form-username">
										<br>
                                            			<label class="sr-only" for="form-email">Email</label>
											<input type="email" name="form-email" required placeholder="Email..." class="form-email form-control" id="form-email">
										<br>
                                            			<label class="sr-only" for="form-password">Password</label>
											<input type="password" name="form-password" required placeholder="Password..." class="form-password form-control" id="form-password">
                                        <br>
                                                        <label class="sr-only" for="form-confirmpassword">Confirm Password</label>
                                            <input type="password" name="form-confirmpassword" required placeholder="Confirm Password..." class="form-confirmpassword form-control" id="form-confirmpassword">
                                        <br>
                                        <br>
											            <label class="sr-only" for="form-phone">Phone</label>
											<input type="tel" min="0" maxlength="10" required name="form-phone" placeholder="Phone..." class="form-phone form-control" id="form-phone">
                                        <br>
                                                        <label class="sr-only" for="form-gender">Gender</label>
                                            <div class="col-xs-3"> <input type="radio" class="radio" name="form-gender" value="male"></div><div class="col-xs-3"><h4 style="color:white">MALE</h4></div>
                                            <div class="col-xs-3"> <input type="radio" class="radio" name="form-gender" value="female"></div><div class="col-xs-3"><h4 style="color:white">Female</h4></div>
										</div>
										<button type="submit" name="btn-signup" class="btn">Sign Up!</button>
									</form>
								</div>
							</div>
							
						<?php /*	<div class="col-sm-4">
							
									<div class="form-top">
										<div class="form-top-left">
											<h3 class="text-center">or<br> Signup with:</h3>
											
										</div>
										
									</div>
								
									<div class="form-bottom">
									
										<div class="social-login-buttons">
											<a class="btn btn-link-2 " href="#">
												<i class="fa fa-facebook"></i>
											</a>
											<a class="btn btn-link-2 " href="#">
												<i class="fa fa-instagram"></i>
											</a>
											<a class="btn btn-link-2 " href="#">
												<i class="fa fa-twitter"></i>
											</a>
											<a class="btn btn-link-2" href="#">
												<i class="fa fa-google-plus"></i>
											</a>
										</div>
							
									</div>
								
							</div> */ ?>
						</div>
                    </div>
                
                      
                    </div>
                </div>
            </div>
            
        </div>
        <div class="footer text-center spacer">
            <p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-instagram fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-flickr fa-2x"></i></a> </p>
            Copyright 2015 Pictomania. All rights reserved.
        </div>
        <!-- # Footer Ends -->


        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>


